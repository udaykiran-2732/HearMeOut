from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', TemplateView.as_view(template_name='landing_page.html'), name='landing'),
    path('tts/', include('tts_converter.urls', namespace='tts_converter')),
    path('stt/', include('stt_converter.urls', namespace='stt_converter')),
    path('sign/', include('sign_language.urls', namespace='sign_language')),
    
    # Add other app URLs here
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)