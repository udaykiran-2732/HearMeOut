
from django.urls import path
from . import views

app_name = "stt_converter"

urlpatterns = [
    path('', views.stt_converter_view, name='stt_converter'),
    #path('transcribe/', views.transcribe_audio, name='transcribe_audio'),
]

