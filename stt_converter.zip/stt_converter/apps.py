from django.apps import AppConfig


class SttConverterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stt_converter'
