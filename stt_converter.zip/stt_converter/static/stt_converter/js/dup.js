 

// Tab switching
document.getElementById("liveTab").onclick = () => {
    document.getElementById("liveSection").classList.remove("hidden");
    document.getElementById("uploadSection").classList.add("hidden");
    document.getElementById("liveTab").classList.add("active");
    document.getElementById("uploadTab").classList.remove("active");
  };
  
  document.getElementById("uploadTab").onclick = () => {
    document.getElementById("uploadSection").classList.remove("hidden");
    document.getElementById("liveSection").classList.add("hidden");
    document.getElementById("uploadTab").classList.add("active");
    document.getElementById("liveTab").classList.remove("active");
  };
  
  // Mic permissions and recording
  let recognition;
  let transcript = "";
  
  if ('webkitSpeechRecognition' in window) {
    recognition = new webkitSpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
  
    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript + " ";
      }
      document.getElementById("transcriptBox").value = transcript.trim();
      document.getElementById("transcriptContainer").classList.remove("hidden");
    };
  }
  
  document.getElementById("startRecord").onclick = () => {
    if (recognition) {
      recognition.lang = "en-US"; // Default or use selected
      recognition.start();
      transcript = "";
      document.getElementById("startRecord").disabled = true;
      document.getElementById("stopRecord").disabled = false;
    } else {
      alert("Speech Recognition not supported or mic access denied.");
    }
  };
  
  document.getElementById("stopRecord").onclick = () => {
    recognition.stop();
    document.getElementById("startRecord").disabled = false;
    document.getElementById("stopRecord").disabled = true;
  };
  
  // File Upload Section
  document.getElementById("audioFile").onchange = function () {
    if (this.files.length > 0) {
      document.getElementById("uploadTick").classList.remove("hidden");
      document.getElementById("transcribeFile").classList.remove("hidden");
    }
  };
  
  document.getElementById("transcribeFile").onclick = function () {
    const lang = "en"; // Grab from dropdown if needed
    const file = document.getElementById("audioFile").files[0];
    const formData = new FormData();
    formData.append("audio", file);
    formData.append("language", lang);
  
    fetch("/stt/convert/", {
      method: "POST",
      body: formData,
    })
      .then((res) => res.json())
      .then((data) => {
        document.getElementById("transcriptBox").value = data.transcript;
        document.getElementById("transcriptContainer").classList.remove("hidden");
      });
  };
  
  // Transcript Buttons
  function copyTranscript() {
    const text = document.getElementById("transcriptBox");
    text.select();
    document.execCommand("copy");
    alert("Copied!");
  }
  
  function downloadTranscript() {
    const text = document.getElementById("transcriptBox").value;
    const blob = new Blob([text], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "transcript.txt";
    link.click();
  }
  
  function shareTranscript() {
    const text = document.getElementById("transcriptBox").value;
    if (navigator.share) {
      navigator.share({ text });
    } else {
      alert("Sharing not supported on this browser.");
    }
  }
  
  // Language search logic (for demo)
  const languages = ["English", "Hindi", "Spanish", "French", "Tamil", "Telugu", "Japanese", "Chinese"];
  const langList = document.getElementById("languageList");
  
  function renderLanguages(filter = "") {
    langList.innerHTML = "";
    languages
      .filter((lang) => lang.toLowerCase().includes(filter.toLowerCase()))
      .forEach((lang) => {
        const div = document.createElement("div");
        div.textContent = lang;
        div.onclick = () => alert(`Selected: ${lang}`);
        langList.appendChild(div);
      });
  }
  
  document.getElementById("languageSearch").oninput = function () {
    renderLanguages(this.value);
  };
  
  renderLanguages(); // Initial load






  document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const languageSearch = document.getElementById('language-search');
    const languageList = document.getElementById('language-list');
    const languageItems = document.querySelectorAll('.language-item');
    const startRecordingBtn = document.getElementById('start-recording');
    const uploadAudioBtn = document.getElementById('upload-audio');
    const fileUploadedBtn = document.getElementById('file-uploaded');
    const transcribeBtn = document.getElementById('transcribe-btn');
    const audioFileInput = document.getElementById('audio-file');
    const transcriptionArea = document.getElementById('transcription-area');
    const copyBtn = document.getElementById('copy-btn');
    const shareBtn = document.getElementById('share-btn');
    const downloadBtn = document.getElementById('download-btn');
    const backBtn = document.getElementById('back-btn');
    const uploadModal = document.getElementById('upload-modal');
    const uploadProgress = document.getElementById('upload-progress');
    const uploadStatus = document.getElementById('upload-status');
  
    // State variables
    let isRecording = false;
    let mediaRecorder = null;
    let audioChunks = [];
    let selectedLanguage = 'en-US'; // Default language
    let recognition = null;
    let selectedFile = null;
  
    // Initialize speech recognition if available
    function initSpeechRecognition() {
        window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        
        if (window.SpeechRecognition) {
            recognition = new SpeechRecognition();
            recognition.continuous = true;
            recognition.interimResults = true;
            recognition.lang = selectedLanguage;
            
            recognition.onresult = (event) => {
                let finalTranscript = '';
                let interimTranscript = '';
                
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }
                
                if (finalTranscript !== '') {
                    updateTranscription(finalTranscript);
                }
            };
            
            recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                stopRecording();
            };
            
            return true;
        } else {
            alert('Speech recognition is not supported in this browser. Please try Chrome or Edge.');
            return false;
        }
    }
  
    // Filter languages based on search
    languageSearch.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        languageItems.forEach(item => {
            const languageName = item.textContent.toLowerCase();
            if (languageName.includes(searchTerm)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    });
  
    // Select language
    languageItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remove selected class from all items
            languageItems.forEach(i => i.classList.remove('selected'));
            
            // Add selected class to clicked item
            this.classList.add('selected');
            
            // Update selected language
            selectedLanguage = this.getAttribute('data-lang');
            
            // Update recognition language if initialized
            if (recognition) {
                recognition.lang = selectedLanguage;
            }
        });
    });
  
    // Start/Stop recording
    startRecordingBtn.addEventListener('click', function() {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    });
  
    // Start recording function
    function startRecording() {
        if (!initSpeechRecognition()) return;
        
        try {
            recognition.start();
            isRecording = true;
            startRecordingBtn.innerHTML = '<i class="fas fa-stop"></i> Stop Recording';
            startRecordingBtn.classList.add('recording');
        } catch (error) {
            console.error('Error starting recording:', error);
        }
    }
  
    // Stop recording function
    function stopRecording() {
        if (recognition) {
            recognition.stop();
        }
        isRecording = false;
        startRecordingBtn.innerHTML = '<i class="fas fa-microphone"></i> Start Recording';
        startRecordingBtn.classList.remove('recording');
    }
  
    // Update transcription area
    function updateTranscription(text) {
        const existingText = transcriptionArea.textContent;
        transcriptionArea.textContent = existingText ? `${existingText} ${text}` : text;
    }
  
    // Trigger file upload
    uploadAudioBtn.addEventListener('click', function() {
        audioFileInput.click();
    });
  
    // Handle file selection
    audioFileInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            selectedFile = file;
            fileUploadedBtn.style.display = 'block';
            transcribeBtn.style.display = 'block';
            
            // Show file name next to tick
            uploadAudioBtn.innerHTML = `<i class="fas fa-file-audio"></i> ${file.name.length > 15 ? file.name.substring(0, 15) + '...' : file.name}`;
        }
    });
    
    // Handle transcribe button click
    transcribeBtn.addEventListener('click', function() {
        if (selectedFile) {
            uploadAudioFile(selectedFile);
        }
    });
  
    // Upload audio file to server
    function uploadAudioFile(file) {
        const formData = new FormData();
        formData.append('audio_file', file);
        formData.append('language', selectedLanguage);
        formData.append('csrfmiddlewaretoken', CSRF_TOKEN);
        
        // Show upload modal
        uploadModal.style.display = 'flex';
        uploadProgress.style.width = '0%';
        uploadStatus.textContent = 'Uploading file...';
        
        // Upload file with progress
        const xhr = new XMLHttpRequest();
        
        xhr.upload.addEventListener('progress', function(e) {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                uploadProgress.style.width = percentComplete + '%';
            }
        });
        
        // In your stt_script.js file
  xhr.addEventListener('load', function() {
    if (xhr.status === 200) {
        uploadStatus.textContent = 'Processing audio...';
        uploadProgress.style.width = '100%';
        
        try {
            const response = JSON.parse(xhr.responseText);
            
            if (response.success && response.transcription) {
                transcriptionArea.textContent = response.transcription;
                uploadModal.style.display = 'none';
            } else {
                uploadStatus.textContent = response.error || 'Error transcribing audio.';
                setTimeout(() => {
                    uploadModal.style.display = 'none';
                }, 2000);
            }
        } catch (e) {
            console.error('Error parsing response:', e);
            uploadStatus.textContent = 'Error processing response.';
            setTimeout(() => {
                uploadModal.style.display = 'none';
            }, 2000);
        }
    } else {
        // This might not handle non-200 responses correctly
        // You need to parse the error response here too
        try {
            const errorResponse = JSON.parse(xhr.responseText);
            uploadStatus.textContent = errorResponse.error || 'Error processing audio.';
        } catch (e) {
            uploadStatus.textContent = 'Error processing audio.';
        }
        setTimeout(() => {
            uploadModal.style.display = 'none';
        }, 2000);
    }
  });
        
        xhr.addEventListener('error', function() {
            uploadStatus.textContent = 'Upload failed.';
            setTimeout(() => {
                uploadModal.style.display = 'none';
            }, 2000);
        });
        
        xhr.open('POST', '/transcribe-audio/', true);
        xhr.send(formData);
    }
  
    // Copy transcription
    copyBtn.addEventListener('click', function() {
        const text = transcriptionArea.textContent;
        if (text) {
            navigator.clipboard.writeText(text)
                .then(() => {
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        this.innerHTML = originalText;
                    }, 2000);
                })
                .catch(err => {
                    console.error('Failed to copy:', err);
                });
        }
    });
  
    // Download transcription
    downloadBtn.addEventListener('click', function() {
        const text = transcriptionArea.textContent;
        if (text) {
            const blob = new Blob([text], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'transcription.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
    });
  
    // Share transcription
    shareBtn.addEventListener('click', function() {
        const text = transcriptionArea.textContent;
        if (text && navigator.share) {
            navigator.share({
                title: 'Speech to Text Transcription',
                text: text
            })
            .catch(err => {
                console.error('Share failed:', err);
            });
        } else {
            alert('Web Share API is not supported in this browser.');
        }
    });
  
    // Back button
    backBtn.addEventListener('click', function() {
        window.location.href = '/';  // Redirect to home page
    });
  
    // Select the default language (English, US)
    const defaultLanguage = document.querySelector('[data-lang="en-US"]');
    if (defaultLanguage) {
        defaultLanguage.classList.add('selected');
    }
  });