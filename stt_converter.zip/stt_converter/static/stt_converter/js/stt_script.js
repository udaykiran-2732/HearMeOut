// DOM Elements
const textOutput = document.getElementById('textOutput');
const startRecordingBtn = document.getElementById('startRecording');
const copyBtn = document.getElementById('copyButton');
const shareBtn = document.getElementById('shareButton');
const downloadBtn = document.getElementById('downloadButton');
const undoBtn = document.getElementById('undoButton');
const redoBtn = document.getElementById('redoButton');
const clearBtn = document.getElementById('clearButton');
const languageItems = document.querySelectorAll('.language-item');
const searchBox = document.querySelector('.search-box');

// History for undo/redo functionality
let history = [''];
let historyIndex = 0;

// Initialize with the first history item
textOutput.value = history[0];

// Speech Recognition Setup
let recognition = null;

// Check if browser supports SpeechRecognition
if ('webkitSpeechRecognition' in window) {
    recognition = new webkitSpeechRecognition();
} else if ('SpeechRecognition' in window) {
    recognition = new SpeechRecognition();
}

if (recognition) {
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-AU'; // Default language

    recognition.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
                finalTranscript += transcript;
            } else {
                interimTranscript += transcript;
            }
        }

        // Update text area with transcription
        if (finalTranscript) {
            textOutput.value += finalTranscript + ' ';
            addToHistory(textOutput.value);
        }
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        toggleRecording(false);
    };

    recognition.onend = () => {
        if (isRecording) {
            recognition.start();
        } else {
            toggleRecording(false);
        }
    };
}

// Recording state
let isRecording = false;

// Event Listeners
startRecordingBtn.addEventListener('click', () => {
    if (!recognition) {
        alert('Speech recognition is not supported in your browser.');
        return;
    }

    if (!isRecording) {
        // Start recording
        recognition.start();
        isRecording = true;
        startRecordingBtn.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="6" y="6" width="12" height="12" rx="2" ry="2"></rect>
            </svg>
            Stop Recording
        `;
        startRecordingBtn.style.backgroundColor = '#f44336';
    } else {
        // Stop recording
        recognition.stop();
        isRecording = false;
        startRecordingBtn.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                <line x1="12" y1="19" x2="12" y2="23"></line>
                <line x1="8" y1="23" x2="16" y2="23"></line>
            </svg>
            Start Recording
        `;
        startRecordingBtn.style.backgroundColor = '#2196f3';
    }
});

// Copy button functionality
copyBtn.addEventListener('click', () => {
    textOutput.select();
    document.execCommand('copy');
    
    // Visual feedback
    copyBtn.textContent = 'Copied!';
    setTimeout(() => {
        copyBtn.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            Copy
        `;
    }, 2000);
});

// Share button
shareBtn.addEventListener('click', () => {
    if (navigator.share) {
        navigator.share({
            title: 'Speech to Text Transcription',
            text: textOutput.value
        })
        .catch(error => console.log('Error sharing:', error));
    } else {
        alert('Web Share API is not supported in your browser.');
    }
});

// Download button
downloadBtn.addEventListener('click', () => {
    const text = textOutput.value;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transcription.txt';
    document.body.appendChild(a);
    a.click();
    
    // Cleanup
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
});

// Undo functionality
undoBtn.addEventListener('click', () => {
    if (historyIndex > 0) {
        historyIndex--;
        textOutput.value = history[historyIndex];
    }
});

// Redo functionality
redoBtn.addEventListener('click', () => {
    if (historyIndex < history.length - 1) {
        historyIndex++;
        textOutput.value = history[historyIndex];
    }
});

// Clear functionality
clearBtn.addEventListener('click', () => {
    textOutput.value = '';
    addToHistory('');
});

// Add to history
function addToHistory(text) {
    // Remove any future history if we're in the middle of the history array
    if (historyIndex < history.length - 1) {
        history = history.slice(0, historyIndex + 1);
    }
    
    // Only add to history if different from the last entry
    if (history[history.length - 1] !== text) {
        history.push(text);
        historyIndex = history.length - 1;
    }
}

// Text area changes
textOutput.addEventListener('input', () => {
    addToHistory(textOutput.value);
});

// Language selection
languageItems.forEach(item => {
    item.addEventListener('click', () => {
        // Remove selected class from all items
        languageItems.forEach(i => i.classList.remove('selected'));
        
        // Add selected class to clicked item
        item.classList.add('selected');
        
        // Update recognition language
        if (recognition) {
            const langCode = item.querySelector('.language-code').textContent;
            recognition.lang = langCode;
        }
    });
});

// Language search
searchBox.addEventListener('input', () => {
    const searchTerm = searchBox.value.toLowerCase();
    
    languageItems.forEach(item => {
        const langName = item.querySelector('div:first-child').textContent.toLowerCase();
        const langCode = item.querySelector('.language-code').textContent.toLowerCase();
        
        if (langName.includes(searchTerm) || langCode.includes(searchTerm)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
});

// Toggle recording helper function
function toggleRecording(isActive) {
    isRecording = isActive;
    if (isActive) {
        startRecordingBtn.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="6" y="6" width="12" height="12" rx="2" ry="2"></rect>
            </svg>
            Stop Recording
        `;
        startRecordingBtn.style.backgroundColor = '#f44336';
    } else {
        startRecordingBtn.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                <line x1="12" y1="19" x2="12" y2="23"></line>
                <line x1="8" y1="23" x2="16" y2="23"></line>
            </svg>
            Start Recording
        `;
        startRecordingBtn.style.backgroundColor = '#2196f3';
    }
}