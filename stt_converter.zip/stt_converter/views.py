# import os
# import json
# import tempfile
# import subprocess
# from django.shortcuts import render
# from django.http import JsonResponse
# from django.views.decorators.csrf import csrf_exempt
# import speech_recognition as sr
# from pydub import AudioSegment
# import logging

# # Set up logging
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# def stt_converter_view(request):
#     """Render the speech to text page"""
#     return render(request, 'stt_converter.html')

# @csrf_exempt
# def transcribe_audio(request):
#     """Handle audio file upload and transcription"""
#     if request.method == 'POST' and request.FILES.get('audio_file'):
#         audio_file = request.FILES['audio_file']
#         language = request.POST.get('language', 'en-US')
        
#         logger.info(f"Received audio file: {audio_file.name}, language: {language}")
        
#         # Get file extension
#         file_extension = os.path.splitext(audio_file.name)[1].lower()
        
#         # Create temporary files
#         temp_input_file = tempfile.NamedTemporaryFile(suffix=file_extension, delete=False)
#         temp_wav_file = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
        
#         try:
#             # Save uploaded file to temp location
#             for chunk in audio_file.chunks():
#                 temp_input_file.write(chunk)
#             temp_input_file.close()
            
#             logger.info(f"Saved uploaded file to {temp_input_file.name}")
            
#             # Convert to WAV if not already WAV
#             if file_extension != '.wav':
#                 try:
#                     # Using pydub for audio conversion
#                     audio = AudioSegment.from_file(temp_input_file.name)
#                     # Set parameters for better recognition
#                     audio = audio.set_channels(1)  # Convert to mono
#                     audio = audio.set_frame_rate(16000)  # Set to 16kHz
#                     audio.export(temp_wav_file.name, format="wav")
#                     logger.info(f"Converted {file_extension} to WAV with mono channel and 16kHz")
#                 except Exception as e:
#                     logger.error(f"Error converting audio: {str(e)}")
#                     return JsonResponse({
#                         'success': False, 
#                         'error': f"Error converting audio format: {str(e)}"
#                     }, status=500)
#             else:
#                 # If already WAV, just copy the file but ensure it's in the right format
#                 try:
#                     audio = AudioSegment.from_file(temp_input_file.name)
#                     audio = audio.set_channels(1)  # Convert to mono
#                     audio = audio.set_frame_rate(16000)  # Set to 16kHz
#                     audio.export(temp_wav_file.name, format="wav")
#                     logger.info("Converted WAV to optimized format (mono, 16kHz)")
#                 except Exception as e:
#                     logger.error(f"Error optimizing WAV file: {str(e)}")
#                     # Fallback to direct copy if optimization fails
#                     with open(temp_input_file.name, 'rb') as src, open(temp_wav_file.name, 'wb') as dst:
#                         dst.write(src.read())
#                     logger.info("Fallback: Direct copy of WAV file")
            
#             # Initialize recognizer
#             r = sr.Recognizer()
            
#             # Set recognition parameters
#             r.energy_threshold = 300  # Minimum audio energy to consider for recording
#             r.dynamic_energy_threshold = True
#             r.pause_threshold = 0.8  # Seconds of non-speaking audio before a phrase is considered complete
            
#             # Process the audio file
#             with sr.AudioFile(temp_wav_file.name) as source:
#                 logger.info("Reading audio file and adjusting for ambient noise")
#                 # Adjust for ambient noise
#                 r.adjust_for_ambient_noise(source, duration=0.5)
#                 # Record audio - explicitly specify the duration
#                 audio_data = r.record(source)
#                 logger.info(f"Audio duration: {len(audio_data.frame_data) / (audio_data.sample_rate * audio_data.sample_width)} seconds")
                
#             # Try recognition
#             try:
#                 logger.info(f"Attempting Google recognition with language: {language}")
#                 transcription = r.recognize_google(audio_data, language=language)
#                 logger.info(f"Transcription successful: {transcription[:50]}...")
#                 return JsonResponse({
#                     'success': True,
#                     'transcription': transcription
#                 })
#             except sr.UnknownValueError:
#                 logger.error("Speech Recognition could not understand audio")
#                 return JsonResponse({
#                     'success': False,
#                     'error': 'Speech Recognition could not understand audio. Please ensure the audio contains clear speech.'
#                 }, status=400)
#             except sr.RequestError as e:
#                 logger.error(f"Could not request results from Google Speech Recognition service: {str(e)}")
                
#                 # Try using an alternative recognition service as backup
#                 # In the transcribe_audio function in your Django view

# # When falling back to Sphinx recognition
#             try:
#                 logger.info("Attempting Sphinx recognition as fallback")
#                 # Sphinx only supports simple language codes (like 'en', not 'en-US')
#                 sphinx_lang = language.split('-')[0] if '-' in language else language
#                 transcription = r.recognize_sphinx(audio_data, language=sphinx_lang)
#                 logger.info(f"Sphinx transcription successful: {transcription[:50]}...")
#                 return JsonResponse({
#                     'success': True,
#                     'transcription': transcription,
#                     'note': 'Used offline recognition (may be less accurate)'
#                 })
#             except Exception as sphinx_error:
#                 logger.error(f"Sphinx recognition failed: {str(sphinx_error)}")
#                 return JsonResponse({
#                     'success': False,
#                     'error': f'Speech recognition services failed. Google error: {str(e)}'
#                 }, status=500)
                
            
#         except Exception as e:
#             logger.error(f"Transcription error: {str(e)}")
#             return JsonResponse({
#                 'success': False,
#                 'error': f'Error processing audio: {str(e)}'
#             }, status=500)
        
        
#         finally:
#             # Clean up temporary files
#             for filepath in [temp_input_file.name, temp_wav_file.name]:
#                 if os.path.exists(filepath):
#                     try:
#                         os.unlink(filepath)
#                         logger.info(f"Deleted temporary file: {filepath}")
#                     except Exception as e:
#                         logger.error(f"Error deleting temporary file {filepath}: {str(e)}")
    
#     return JsonResponse({'success': False, 'error': 'Invalid request or no audio file provided'}, status=400)






from django.shortcuts import render

def stt_converter_view(request):
    return render(request, 'stt_converter.html')