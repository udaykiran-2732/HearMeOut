function doActive(className) {
    $("." + className).toggleClass("active");
  }
  
  function doActiveType(className, type) {
    $("." + type + "-action").removeClass("active");
    $("." + type + "-img").removeClass("active");
    $("." + type + "-action-" + className).addClass("active");
    $("." + type + "-img-" + className).toggleClass("active");
    if (type == "property") {
      if (className == "1") {
        $(".property .container-area .left-area .description").html(
          "Students & Educators"
        );
      } else if (className == "2") {
        $(".property .container-area .left-area .description").html(
          "Healthcare Professionals"
        );
      } else if (className == "3") {
        $(".property .container-area .left-area .description").html(
          "Workplaces & Businesses"
        );
      } else if (className == "4") {
        $(".property .container-area .left-area .description").html(
          "Public Services & Customer Support"
        );
      } else if (className == "5") {
        $(".property .container-area .left-area .description").html(
          "Event Organizers & Media"
        );
      } else if (className == "6") {
        $(".property .container-area .left-area .description").html(
          "Families & Caregivers"
        );
      } else if (className == "7") {
        $(".property .container-area .left-area .description").html(
          "Deaf Individuals"
        );
      } else if (className == "8") {
        $(".property .container-area .left-area .description").html(
          "Mute Individuals"
        );
      }
    }
  }
  
  function accordion(className) {
    $(".accordion." + className).toggleClass("active");
  }
  
  function cardAccordion(className) {
    $(".card-accordion." + className).toggleClass("active");
  }
  
  $(".customize").on("click", ".settings", function (event) {
    var count = $(this.attributes[1]).val();
    var t = $(this.attributes[2]).val();
    var total = parseInt(t) + 1;
    var parent = $(this.classList)[1];
    count++;
    if (count == total) {
      $(this).attr("aria-label", 0);
      $(`.${parent}`).removeClass("active");
      $(`.${parent} .info-area .steps .step`).removeClass("active");
      $(`.${parent} .info-area .titles .title`).removeClass("active");
      $(`.${parent} .info-area .titles .title-0`).addClass("active");
    } else {
      console.log(`.${parent} .info-area .titles .title-${count}`);
      $(this).attr("aria-label", count);
      $(`.${parent} .info-area .steps .step-${count}`).addClass("active");
      $(`.${parent} .info-area .titles .title`).removeClass("active");
      $(`.${parent} .info-area .titles .title-${count}`).addClass("active");
      if (count == 1) {
        $(this).attr("aria-label", count);
        $(this).addClass("active");
      }
    }
  });
  
  $(".dropdown-card").on("click", ".dropdown-lang-btn", function () {
    $(".dropdown-lang-btn").removeClass("active");
    $(this).addClass("active");
    var text = $(this).attr("aria-label");
    var shortText = $(this).attr("aria-valuetext");
    $("#lang-text").html(text);
    $("#lang-img").attr("src", `/styles/img/${shortText}_flag.png`);
    console.log(text, shortText);
  });
  
  function mySign(btnId) {
    $(".text").removeClass("active");
    $(".text.num-" + btnId).addClass("active");
    $(".signup-card>div").removeClass("active");
    $("." + btnId).addClass("active");
  }
  
  var typePagesNum = 0;
  function typePages(dir) {
    var list = document.getElementsByClassName("customize-area");
    $(".step").removeClass("active");
    if (dir == "increase") {
      if (typePagesNum < list.length - 1) {
        typePagesNum = typePagesNum + 1;
        $(".slide").removeClass("slide-" + (typePagesNum - 1));
      }
    } else {
      if (typePagesNum > 0) {
        typePagesNum = typePagesNum - 1;
        $(".slide").removeClass("slide-" + (typePagesNum + 1));
      }
    }
    $(".slide").addClass("slide-" + typePagesNum);
    $(".step.step-" + typePagesNum).addClass("active");
    $(".customize-area").removeClass("active");
    list[typePagesNum].classList.add("active");
    var bodyHeight = $(document).height();
    if (window.innerHeight < bodyHeight) {
      $(".customize-btn-area").addClass("shadow");
    } else {
      $(".customize-btn-area").removeClass("shadow");
    }
  }
  
  function copy() {
    var copyText = document.getElementById("copy").innerHTML;
    navigator.clipboard.writeText(copyText);
  }
  
  $(document).on("click", function (event) {
    var $trigger = $(".profile");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
      $(".profile-dropdown").removeClass("active");
    }
  
    var $trigger2 = $(".dropdown-area");
    if ($trigger2 !== event.target && !$trigger2.has(event.target).length) {
      $(".dropdown-card").removeClass("active");
    }
  });
  
  function modal(modalClass) {
    $("." + modalClass).addClass("active");
  }
  
  $(".modal-cancel").click(() => {
    $(".modal").removeClass("active");
  });
  
  var charNo = 0;
  function creditCardNo() {
    var text = $("#cardNo").val();
    var list = $(".card-no span");
    charNo = text.length;
    var lastText = text[charNo - 1];
    list[charNo - 1].innerHTML = lastText;
  }
  
  function creditCardName() {
    var text = $("#cardName").val();
    if (text == "") {
      $(".card-name").html("Ä°sim Soyisim").addClass("passive");
    } else {
      $(".card-name").html(text).removeClass("passive");
    }
  }
  
  const count = ["01", "02", "03"];
  const title = [
    "Ä°ÅŸaret Dili Web Eklentisi 1",
    "Ä°ÅŸaret Dili Web Eklentisi 2",
    "Ä°ÅŸaret Dili Web Eklentisi 3",
  ];
  const desc = ["desc 1", "desc 2", "desc 3"];
  const img = [
    "../styles/img/carousel-img-1.png",
    "../styles/img/carousel-img-2.png",
    "../styles/img/carousel-img-3.png",
  ];
  
  function createDots() {
    for (var i = 0; i <= count.length - 1; i++) {
      $("#dots").append("<div class='dot'></div>");
    }
  }
  
  createDots();
  
  var arr = $("body").find(".dot");
  
  function customizeLocation(location) {
    $(".customize .location input[type='radio']").removeAttr("checked");
    $(".customize ." + location + "-location input[type='radio']").attr(
      "checked",
      "checked"
    );
    $(".customize-area")
      .removeClass("top")
      .removeClass("left")
      .removeClass("right")
      .addClass(location);
  }
  
  $(document).ready(function () {});
  
  
  
  
  
  function mediaNext(type) {
    var page = $("." + type + "-move-area").attr("aria-label");
    var mediaArray = $("#" + type).find(".media");
    var mediaCount = mediaArray.length;
    var showCount;
    if (window.innerWidth > 1365) {
      showCount = 5;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -1250 * page);
    } else if (window.innerWidth > 1100) {
      showCount = 4;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -1000 * page);
    } else if (window.innerWidth > 600) {
      showCount = 2;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -500 * page);
    } else {
      showCount = 1;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -250 * page);
    }
    page = parseInt(page) + 1;
    $("." + type + "-move-area").attr("aria-label", page);
    console.log(page);
    if (mediaCount % showCount == 0) {
      if (page == moveCount + 1) {
        page = 1;
        $("." + type + "-move-area").attr("aria-label", page);
        $("." + type + "-move-area").css("left", 0);
      }
    } else {
      if (page == moveCount + 2) {
        page = 1;
        $("." + type + "-move-area").attr("aria-label", page);
        $("." + type + "-move-area").css("left", 0);
      }
    }
    console.log(window.innerWidth);
  }
  
  function mediaPrev(type) {
    var page = $("." + type + "-move-area").attr("aria-label"); // page  = 1
    page = parseInt(page) - 1; // page = 0
    var mediaArray = $("#" + type).find(".media");
    var mediaCount = mediaArray.length;
    var showCount;
    if (window.innerWidth > 1365) {
      showCount = 5;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -1250 * (page - 1));
    } else if (window.innerWidth > 1100) {
      showCount = 4;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -1000 * (page - 1));
    } else if (window.innerWidth > 600) {
      showCount = 2;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -500 * (page - 1));
    } else {
      showCount = 1;
      var moveCount = Math.floor(mediaCount / showCount);
      $("." + type + "-move-area").css("left", -250 * (page - 1));
    }
    $("." + type + "-move-area").attr("aria-label", page);
  
    if (page == 0) {
      if (mediaCount % showCount == 0) {
        page = moveCount;
      } else {
        page = moveCount + 1;
      }
      $("." + type + "-move-area").attr("aria-label", page);
      if (window.innerWidth > 1365) {
        var moveCount = Math.floor(mediaCount / 5);
        $("." + type + "-move-area").css("left", -1250 * (page - 1));
      } else if (window.innerWidth > 1100) {
        var moveCount = Math.floor(mediaCount / 4);
        $("." + type + "-move-area").css("left", -1000 * (page - 1));
      } else if (window.innerWidth > 600) {
        showCount = 2;
        var moveCount = Math.floor(mediaCount / showCount);
        $("." + type + "-move-area").css("left", -500 * (page - 1));
      } else {
        showCount = 1;
        var moveCount = Math.floor(mediaCount / showCount);
        $("." + type + "-move-area").css("left", -250 * (page - 1));
      }
      // $(".medias-move-area").css("left", -1250 * (page - 1));
    }
  }
  
  function activeMission(title,myThis,contentArea) {
    // $(".m-v-left-card").removeClass("active");
    // $(".m-v-right").removeClass("active");
    // $(".change-btn").removeClass("active");
    // $("." + type).addClass("active");
  
    // myAboutUsArea myMissionArea myVisionArea about-us myAboutUsArea
    $(".titleTab").html(title)
    $(".about-us.myAboutUsArea").removeClass("active")
    $(".vision.myVisionArea").removeClass("active")
    $(".mission.myMissionArea").removeClass("active")
    $("."+contentArea).addClass("active")
  }
  
  function doActiveRequest(num) {
    $(".demo-button").removeClass("active");
    $(".demo-button-" + num).addClass("active");
    $(".demo-description").removeClass("active");
    $(".demo-description-" + num).addClass("active");
    $(".demo-form").removeClass("active");
  }
  
  function getForm(num) {
    $(".demo-description").removeClass("active");
    $(".demo-form").addClass("active");
    var title = $(".demo-description-" + num + " .demo-title").html();
    var info = $(".demo-description-" + num + " .demo-info").html();
    $(".demo-form .demo-form-title").html(title);
    $(".demo-form .demo-form-info").html(info);
    const $select = document.querySelector('#demos');
    $select.value = 'demo' + num;
  }
  
  // string // "asasd"
  // int  // 1232
  // double // 12.34
  // float // 12.333333
  // array // ["aaa",11 , true]
  // list //
  // char // "a" "-"
  // boolean // true - false