# from django.shortcuts import render
# from django.http import JsonResponse, HttpResponse
# import os
# from django.conf import settings
# import PyPDF2
# import docx
# import io

def tts_converter_view(request):
    return render(request, 'tts_converter.html')

# def upload_file(request):
#     if request.method == 'POST' and request.FILES.get('file'):
#         uploaded_file = request.FILES['file']
        
#         # Get file extension to determine file type
#         file_name = uploaded_file.name
#         file_extension = os.path.splitext(file_name)[1].lower()
        
#         text_content = ""
        
#         # Process based on file type
#         if file_extension == '.txt':
#             text_content = uploaded_file.read().decode('utf-8')
        
#         elif file_extension == '.pdf':
#             try:
#                 pdf_reader = PyPDF2.PdfReader(io.BytesIO(uploaded_file.read()))
#                 for page in pdf_reader.pages:
#                     text_content += page.extract_text()
#             except Exception as e:
#                 return JsonResponse({'error': f'Error processing PDF: {str(e)}'}, status=400)
        
#         elif file_extension in ['.doc', '.docx']:
#             try:
#                 doc = docx.Document(io.BytesIO(uploaded_file.read()))
#                 for para in doc.paragraphs:
#                     text_content += para.text + '\n'
#             except Exception as e:
#                 return JsonResponse({'error': f'Error processing DOCX: {str(e)}'}, status=400)
        
#         else:
#             return JsonResponse({'error': 'Unsupported file type'}, status=400)
        
#         return JsonResponse({'text': text_content})
    
#     return JsonResponse({'error': 'No file uploaded'}, status=400)




import os
import uuid
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from django.http import JsonResponse
from PyPDF2 import PdfReader
import docx
from gtts import gTTS

# Directory for storing uploaded files
UPLOAD_DIR = 'media/uploads/'
AUDIO_DIR = 'media/audio/'
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(AUDIO_DIR, exist_ok=True)

def extract_text(file_path, file_type):
    if file_type == 'pdf':
        reader = PdfReader(file_path)
        return "\n".join([page.extract_text() for page in reader.pages if page.extract_text()])
    elif file_type == 'docx':
        doc = docx.Document(file_path)
        return "\n".join([para.text for para in doc.paragraphs])
    elif file_type == 'txt':
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

def upload_file(request):
    if request.method == 'POST' and request.FILES.get('file'):
        uploaded_file = request.FILES['file']
        file_ext = uploaded_file.name.split('.')[-1].lower()
        if file_ext not in ['pdf', 'docx', 'txt']:
            return JsonResponse({'error': 'Unsupported file format'}, status=400)
        
        fs = FileSystemStorage(location=UPLOAD_DIR)
        filename = fs.save(uploaded_file.name, uploaded_file)
        file_path = os.path.join(UPLOAD_DIR, filename)
        extracted_text = extract_text(file_path, file_ext)
        
        return JsonResponse({'text': extracted_text})
    return JsonResponse({'error': 'Invalid request'}, status=400)

def text_to_speech(request):
    if request.method == 'POST':
        text = request.POST.get('text', '')
        if not text.strip():
            return JsonResponse({'error': 'No text provided'}, status=400)
        
        audio_filename = f"tts_{uuid.uuid4().hex}.mp3"
        audio_path = os.path.join(AUDIO_DIR, audio_filename)
        tts = gTTS(text)
        tts.save(audio_path)
        
        return JsonResponse({'audio_url': f'/media/tts_converter/audio/{audio_filename}'})
    return JsonResponse({'error': 'Invalid request'}, status=400)

