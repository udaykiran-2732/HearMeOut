from django import forms
from .models import TextToSpeech

class TTSForm(forms.ModelForm):
    class Meta:
        model = TextToSpeech
        fields = ['text']