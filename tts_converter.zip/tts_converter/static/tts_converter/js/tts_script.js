document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const textInput = document.getElementById('text-input');
    const charCount = document.getElementById('char-count');
    const wordCount = document.getElementById('word-count');
    const undoBtn = document.getElementById('undo-btn');
    const redoBtn = document.getElementById('redo-btn');
    const clearBtn = document.getElementById('clear-btn');
    const fileInput = document.getElementById('file-input');
    const fileName = document.getElementById('file-name');
    const voiceSelectBtn = document.getElementById('voice-select-btn');
    const modal = document.getElementById('voice-modal');
    const closeModal = document.querySelector('.close');
    const voiceList = document.getElementById('voice-list');
    const voiceSearch = document.getElementById('voice-search');
    const genderFilters = document.querySelectorAll('.filter-btn');
    const countryFilter = document.getElementById('country-filter');
    const volumeSlider = document.getElementById('volume');
    const volumeValue = document.getElementById('volume-value');
    const rateSlider = document.getElementById('rate');
    const rateValue = document.getElementById('rate-value');
    const pitchSlider = document.getElementById('pitch');
    const pitchValue = document.getElementById('pitch-value');
    const audioFormat = document.getElementById('audio-format');
    const playBtn = document.getElementById('play-btn');
    const downloadBtn = document.getElementById('download-btn');
    const loadingOverlay = document.getElementById('loading-overlay');
    const loadingMessage = document.getElementById('loading-message');

    // State variables
    let speechSynthesis = window.speechSynthesis;
    let voices = [];
    let selectedVoice = null;
    let currentUtterance = null;
    let isPlaying = false;
    let textHistory = [''];
    let historyIndex = 0;
    let countries = [];
    let audioBlob = null;
    let mediaRecorder = null;
    let audioChunks = [];

    // Setup external libraries
    if (window.pdfjsLib) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
    }

    // Initialize undo/redo functionality
    function saveToHistory(text) {
        if (textHistory[historyIndex] !== text) {
            textHistory = textHistory.slice(0, historyIndex + 1);
            textHistory.push(text);
            historyIndex = textHistory.length - 1;
            updateUndoRedoButtons();
        }
    }

    function updateUndoRedoButtons() {
        undoBtn.disabled = historyIndex <= 0;
        redoBtn.disabled = historyIndex >= textHistory.length - 1;
    }

    function updateTextStats() {
        const text = textInput.value;
        const characterCount = text.length;
        const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
        
        charCount.textContent = `${characterCount} character${characterCount !== 1 ? 's' : ''}`;
        wordCount.textContent = `${wordCount} word${wordCount !== 1 ? 's' : ''}`;
    }

    // Undo button functionality
    undoBtn.addEventListener('click', function() {
        if (historyIndex > 0) {
            historyIndex--;
            textInput.value = textHistory[historyIndex];
            updateTextStats();
            updateUndoRedoButtons();
        }
    });

    // Redo button functionality
    redoBtn.addEventListener('click', function() {
        if (historyIndex < textHistory.length - 1) {
            historyIndex++;
            textInput.value = textHistory[historyIndex];
            updateTextStats();
            updateUndoRedoButtons();
        }
    });

    // Clear button functionality
    clearBtn.addEventListener('click', function() {
        textInput.value = '';
        saveToHistory('');
        updateTextStats();
    });

    // Text input event
    textInput.addEventListener('input', function() {
        updateTextStats();
        setTimeout(() => {
            saveToHistory(textInput.value);
        }, 500);
    });

    // Show loading overlay
    function showLoading(message) {
        loadingMessage.textContent = message || 'Processing...';
        loadingOverlay.style.display = 'flex';
    }

    // Hide loading overlay
    function hideLoading() {
        loadingOverlay.style.display = 'none';
    }

    // Process PDF file
    async function processPDF(file) {
        showLoading('Extracting text from PDF...');
        
        try {
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            let text = '';
            
            // Extract text from each page
            for (let i = 1; i <= pdf.numPages; i++) {
                const page = await pdf.getPage(i);
                const content = await page.getTextContent();
                const pageText = content.items.map(item => item.str).join(' ');
                text += pageText + '\n\n';
            }
            
            return text.trim();
        } catch (error) {
            console.error('Error processing PDF:', error);
            throw new Error('Failed to extract text from PDF');
        } finally {
            hideLoading();
        }
    }

    // Process DOC/DOCX file using mammoth
    async function processDocx(file) {
        showLoading('Extracting text from document...');
        
        try {
            const arrayBuffer = await file.arrayBuffer();
            const result = await mammoth.extractRawText({ arrayBuffer });
            return result.value;
        } catch (error) {
            console.error('Error processing DOCX:', error);
            throw new Error('Failed to extract text from document');
        } finally {
            hideLoading();
        }
    }

    // File input handling
    fileInput.addEventListener('change', async function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        fileName.textContent = file.name;
        
        try {
            let extractedText = '';
            
            if (file.type === 'application/pdf') {
                extractedText = await processPDF(file);
            } else if (file.name.endsWith('.doc') || file.name.endsWith('.docx') || 
                      file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
                      file.type === 'application/msword') {
                extractedText = await processDocx(file);
            } else {
                // For TXT files and others
                showLoading('Reading text file...');
                const fileReader = new FileReader();
                
                extractedText = await new Promise((resolve, reject) => {
                    fileReader.onload = function() {
                        resolve(fileReader.result);
                    };
                    fileReader.onerror = reject;
                    fileReader.readAsText(file);
                });
            }
            
            textInput.value = extractedText;
            saveToHistory(extractedText);
            updateTextStats();
            
        } catch (error) {
            alert(`Error processing file: ${error.message}`);
        } finally {
            hideLoading();
        }
    });

    // Voice selection modal
    voiceSelectBtn.addEventListener('click', function() {
        modal.style.display = 'block';
        loadVoices();
    });

    closeModal.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Populate voices
    function loadVoices() {
        voices = speechSynthesis.getVoices();
        
        // Extract countries from voices
        countries = [...new Set(voices.map(voice => {
            const langCode = voice.lang.split('-')[1];
            return getCountryName(langCode);
        }))].sort();
        
        // Populate country filter
        countryFilter.innerHTML = '<option value="all">All Countries</option>';
        countries.forEach(country => {
            if (country) {
                const option = document.createElement('option');
                option.value = country;
                option.textContent = country;
                countryFilter.appendChild(option);
            }
        });
        
        filterVoices();
    }

    function getCountryName(code) {
        if (!code) return 'Unknown';
        
        // Basic mapping of common country codes
        const countryMap = {
            'US': 'United States',
            'GB': 'United Kingdom',
            'CA': 'Canada',
            'AU': 'Australia',
            'IN': 'India',
            'FR': 'France',
            'DE': 'Germany',
            'JP': 'Japan',
            'CN': 'China',
            'ES': 'Spain',
            'IT': 'Italy',
            'BR': 'Brazil',
            'MX': 'Mexico',
            'KR': 'South Korea'
            // Add more as needed
        };
        
        return countryMap[code] || code;
    }

    function getGender(voiceName) {
        voiceName = voiceName.toLowerCase();
        
        if (voiceName.includes('child') || voiceName.includes('kid')) {
            return 'child';
        } else if (voiceName.includes('female') || 
                  voiceName.includes('woman') || 
                  /girl|fiona|alice|victoria|karen|susan|zira|lisa|catherine|lekha|samantha/i.test(voiceName)) {
            return 'female';
        } else {
            return 'male'; // Default to male
        }
    }

    function filterVoices() {
        const searchTerm = voiceSearch.value.toLowerCase();
        const selectedGender = document.querySelector('.filter-btn.active').dataset.gender;
        const selectedCountry = countryFilter.value;
        
        voiceList.innerHTML = '';
        
        voices.forEach(voice => {
            const langCode = voice.lang.split('-')[1];
            const country = getCountryName(langCode);
            const gender = getGender(voice.name);
            
            if (
                (selectedGender === 'all' || gender === selectedGender) &&
                (selectedCountry === 'all' || country === selectedCountry) &&
                (voice.name.toLowerCase().includes(searchTerm) || 
                 voice.lang.toLowerCase().includes(searchTerm) ||
                 country.toLowerCase().includes(searchTerm))
            ) {
                const li = document.createElement('li');
                li.className = 'voice-item';
                if (selectedVoice && voice.name === selectedVoice.name) {
                    li.classList.add('selected');
                }
                
                li.innerHTML = `
                    <div class="voice-info">
                        <span class="voice-name">${voice.name}</span>
                        <span class="voice-details">${country} (${gender})</span>
                    </div>
                    <button class="play-sample">Sample</button>
                `;
                
                li.querySelector('.play-sample').addEventListener('click', function(e) {
                    e.stopPropagation();
                    speakSample(voice);
                });
                
                li.addEventListener('click', function() {
                    document.querySelectorAll('.voice-item').forEach(item => {
                        item.classList.remove('selected');
                    });
                    li.classList.add('selected');
                    selectedVoice = voice;
                    voiceSelectBtn.innerHTML = `<i class="fas fa-user-alt"></i> <span>${voice.name}</span>`;
                    modal.style.display = 'none';
                });
                
                voiceList.appendChild(li);
            }
        });
        
        if (voiceList.children.length === 0) {
            const noResults = document.createElement('li');
            noResults.className = 'voice-item';
            noResults.textContent = 'No voices match your criteria';
            voiceList.appendChild(noResults);
        }
    }

    function speakSample(voice) {
        stopSpeaking();
        
        const sampleText = "This is a sample of my voice.";
        const utterance = new SpeechSynthesisUtterance(sampleText);
        utterance.voice = voice;
        utterance.volume = volumeSlider.value;
        utterance.rate = rateSlider.value;
        utterance.pitch = pitchSlider.value;
        
        speechSynthesis.speak(utterance);
    }

    // Voice filter event listeners
    voiceSearch.addEventListener('input', filterVoices);
    countryFilter.addEventListener('change', filterVoices);
    
    genderFilters.forEach(button => {
        button.addEventListener('click', function() {
            genderFilters.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            filterVoices();
        });
    });

    // Slider controls
    volumeSlider.addEventListener('input', function() {
        volumeValue.textContent = `${Math.round(this.value * 100)}%`;
        if (isPlaying && currentUtterance) {
            currentUtterance.volume = this.value;
        }
    });

    rateSlider.addEventListener('input', function() {
        rateValue.textContent = `${this.value}x`;
        if (isPlaying && currentUtterance) {
            currentUtterance.rate = this.value;
        }
    });

    pitchSlider.addEventListener('input', function() {
        pitchValue.textContent = this.value;
        if (isPlaying && currentUtterance) {
            currentUtterance.pitch = this.value;
        }
    });

    // Speaking functionality
    function speak() {
        const text = textInput.value;
        if (!text) {
            alert("Please enter some text to convert to speech.");
            return;
        }
        
        if (isPlaying) {
            stopSpeaking();
            return;
        }
        
        // Set up utterance
        currentUtterance = new SpeechSynthesisUtterance(text);
        
        if (selectedVoice) {
            currentUtterance.voice = selectedVoice;
        }
        
        currentUtterance.volume = volumeSlider.value;
        currentUtterance.rate = rateSlider.value;
        currentUtterance.pitch = pitchSlider.value;
        
        // Event listeners
        currentUtterance.onstart = function() {
            isPlaying = true;
            playBtn.innerHTML = `<i class="fas fa-pause"></i> Pause`;
            playBtn.classList.add('pause');
            
            // Start recording for download
            startRecording();
        };
        
        currentUtterance.onend = function() {
            isPlaying = false;
            playBtn.innerHTML = `<i class="fas fa-play"></i> Convert to Speech`;
            playBtn.classList.remove('pause');
            
            // Stop recording and prepare download
            stopRecording();
        };
        
        currentUtterance.onpause = function() {
            isPlaying = false;
            playBtn.innerHTML = `<i class="fas fa-play"></i> Resume`;
            playBtn.classList.remove('pause');
        };
        
        currentUtterance.onresume = function() {
            isPlaying = true;
            playBtn.innerHTML = `<i class="fas fa-pause"></i> Pause`;
            playBtn.classList.add('pause');
        };
        
        // Start speaking
        speechSynthesis.speak(currentUtterance);
    }

    function stopSpeaking() {
        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
        }
        
        isPlaying = false;
        playBtn.innerHTML = `<i class="fas fa-play"></i> Convert to Speech`;
        playBtn.classList.remove('pause');
        
        if (mediaRecorder && mediaRecorder.state === 'recording') {
            mediaRecorder.stop();
        }
    }

    // Play button event
    playBtn.addEventListener('click', speak);

    // Audio recording for download
    function startRecording() {
        // Create audio context for recording
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const destination = audioContext.createMediaStreamDestination();
        audioChunks = [];
        
        try {
            // Create a media recorder to capture the audio stream
            mediaRecorder = new MediaRecorder(destination.stream);
            
            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    audioChunks.push(event.data);
                }
            };
            
            mediaRecorder.onstop = () => {
                // Create blob from recorded chunks
                const format = audioFormat.value;
                const mimeType = `audio/${format}`;
                const blob = new Blob(audioChunks, { type: mimeType });
                audioBlob = blob;
                downloadBtn.disabled = false;
            };
            
            mediaRecorder.start();
        } catch (error) {
            console.error("Error setting up media recorder:", error);
            // Fallback for browsers that don't support MediaRecorder
            simulateRecording();
        }
    }
    
    function simulateRecording() {
        console.log("Using simulated recording fallback");
        // For demo purposes, we'll simulate a recording
        setTimeout(() => {
            const format = audioFormat.value;
            const blob = new Blob([new ArrayBuffer(1000)], { type: `audio/${format}` });
            audioBlob = blob;
            downloadBtn.disabled = false;
        }, 1000);
    }

    function stopRecording() {
        if (mediaRecorder && mediaRecorder.state === 'recording') {
            mediaRecorder.stop();
        }
    }

    // Download button
    downloadBtn.addEventListener('click', function() {
        if (!audioBlob) {
            alert("No audio available for download. Please convert text to speech first.");
            return;
        }
        
        const format = audioFormat.value;
        const url = URL.createObjectURL(audioBlob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        
        // Create a filename with current date/time
        const date = new Date();
        const timestamp = `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}_${date.getHours().toString().padStart(2, '0')}-${date.getMinutes().toString().padStart(2, '0')}`;
        a.download = `voicetext_${timestamp}.${format}`;
        
        document.body.appendChild(a);
        a.click();
        
        setTimeout(() => {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);
    });

    // Initialize voices when they're available
    if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = loadVoices;
    }
    
    // Initial setup
    loadVoices();
    updateTextStats();
    updateUndoRedoButtons();
    
});
    // Clear button functionality
    clearBtn.addEventListener('click', function() {
        textInput.value = '';
        saveToHistory('');
        updateTextStats();
    });









