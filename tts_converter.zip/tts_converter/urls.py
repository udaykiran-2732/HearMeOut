from django.urls import path
from . import views

app_name = 'tts_converter'

urlpatterns = [
    path('', views.tts_converter_view, name='tts_converter'),
    # path('upload/', views.upload_file, name='upload_file'),
]