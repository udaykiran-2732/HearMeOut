from django.apps import AppConfig


class TtsConverterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tts_converter'
